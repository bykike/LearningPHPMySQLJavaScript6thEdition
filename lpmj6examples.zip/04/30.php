<?php
  $count = 0;

  while (++$count <= 12)
	echo "$count times 12 is " . $count * 12 . "<br>";
?>
