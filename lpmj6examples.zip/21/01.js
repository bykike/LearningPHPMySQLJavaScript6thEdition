function O(i)
{
  return typeof i == 'object' ? i : document.getElementById(i)
}
