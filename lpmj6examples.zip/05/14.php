<?php
  class User
  {
      function __construct($param1, $param2)
    {
      // Constructor statements go here
    }
  }
?>
