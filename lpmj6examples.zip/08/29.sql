SELECT name,author,title from customers,classics
 WHERE customers.isbn=classics.isbn;
